import 'package:flutter/material.dart';
import 'app_colors.dart';

/// Central text style definitions. Font family defaults to the system
/// rounded-ish look seen in the mockup; swap [fontFamily] below once you
/// add the real brand font (e.g. via google_fonts or pubspec assets).
class AppTextStyles {
  AppTextStyles._();

  static const String fontFamily = 'Poppins';

  static const TextStyle logoTitle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 32,
    fontWeight: FontWeight.w800,
    color: AppColors.primaryTealDark,
    height: 1.1,
  );

  static const TextStyle subtitle = TextStyle(
    fontFamily: fontFamily,
    fontSize: 16,
    fontWeight: FontWeight.w600,
    color: AppColors.textSubtitle,
    height: 1.4,
  );

  static const TextStyle primaryButtonLabel = TextStyle(
    fontFamily: fontFamily,
    fontSize: 17,
    fontWeight: FontWeight.w600,
    color: AppColors.textOnPrimaryButton,
  );

  static const TextStyle secondaryButtonLabel = TextStyle(
    fontFamily: fontFamily,
    fontSize: 17,
    fontWeight: FontWeight.w600,
    color: AppColors.primaryTeal,
  );
}
