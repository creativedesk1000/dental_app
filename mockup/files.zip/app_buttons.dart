import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';

/// Solid cyan CTA button (e.g. "Create an Account").
class PrimaryAppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final double height;

  const PrimaryAppButton({
    super.key,
    required this.label,
    this.onPressed,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.accentCyan,
          foregroundColor: AppColors.textOnPrimaryButton,
          elevation: 4,
          shadowColor: AppColors.accentCyan.withOpacity(0.4),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: Text(label, style: AppTextStyles.primaryButtonLabel),
      ),
    );
  }
}

/// White outlined/elevated button (e.g. "Sign in").
class SecondaryAppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final double height;

  const SecondaryAppButton({
    super.key,
    required this.label,
    this.onPressed,
    this.height = 56,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: height,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.secondaryButtonBg,
          foregroundColor: AppColors.primaryTeal,
          elevation: 3,
          shadowColor: Colors.black.withOpacity(0.08),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: Text(label, style: AppTextStyles.secondaryButtonLabel),
      ),
    );
  }
}
