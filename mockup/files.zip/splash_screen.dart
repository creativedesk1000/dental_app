import 'package:flutter/material.dart';
import '../theme/app_colors.dart';
import '../theme/app_text_styles.dart';
import '../widgets/app_buttons.dart';
import '../widgets/splash_illustration.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({super.key});

  static const String routeName = '/splash';

  @override
  Widget build(BuildContext context) {
    final width = MediaQuery.of(context).size.width;

    // Breakpoint: treat >= 600 logical px as tablet.
    final bool isTablet = width >= 600;

    // Scale content so it doesn't stretch edge-to-edge on large tablets.
    final double maxContentWidth = isTablet ? 480 : double.infinity;
    final double illustrationSize = isTablet ? 300 : 220;
    final double horizontalPadding = isTablet ? 32 : 24;

    return Scaffold(
      backgroundColor: AppColors.background,
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: maxContentWidth),
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: horizontalPadding),
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return SingleChildScrollView(
                    physics: const ClampingScrollPhysics(),
                    child: ConstrainedBox(
                      constraints: BoxConstraints(
                        minHeight: constraints.maxHeight > 0
                            ? MediaQuery.of(context).size.height -
                                MediaQuery.of(context).padding.top -
                                MediaQuery.of(context).padding.bottom
                            : 0,
                      ),
                      child: IntrinsicHeight(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            SizedBox(height: isTablet ? 48 : 32),

                            // Illustration
                            Center(
                              child: SplashIllustration(size: illustrationSize),
                            ),

                            SizedBox(height: isTablet ? 40 : 28),

                            // Logo + brand name
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.emergency_share_rounded,
                                  color: AppColors.primaryTeal,
                                  size: isTablet ? 40 : 34,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  'Dental Care',
                                  style: AppTextStyles.logoTitle.copyWith(
                                    fontSize: isTablet ? 38 : 32,
                                  ),
                                ),
                              ],
                            ),

                            SizedBox(height: isTablet ? 28 : 20),

                            // Subtitle
                            Text(
                              'Ensure a speedy recovery with our '
                              'post-operative care instructions '
                              'for dental patients',
                              textAlign: TextAlign.center,
                              style: AppTextStyles.subtitle.copyWith(
                                fontSize: isTablet ? 18 : 16,
                              ),
                            ),

                            const Spacer(),
                            SizedBox(height: isTablet ? 48 : 32),

                            // Primary CTA
                            PrimaryAppButton(
                              label: 'Create an Account',
                              onPressed: () {
                                // TODO: navigate to sign up screen
                              },
                            ),

                            const SizedBox(height: 14),

                            // Secondary CTA
                            SecondaryAppButton(
                              label: 'Sign in',
                              onPressed: () {
                                // TODO: navigate to sign in screen
                              },
                            ),

                            SizedBox(height: isTablet ? 32 : 20),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),
        ),
      ),
    );
  }
}
