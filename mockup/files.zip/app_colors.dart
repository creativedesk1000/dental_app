import 'package:flutter/material.dart';

/// Central color palette for the Dental Care app.
/// Pulled from the splash screen mockup — reuse these across all screens
/// so the app stays visually consistent.
class AppColors {
  AppColors._();

  // Primary brand teal/cyan (logo, headline, subtitle text)
  static const Color primaryTeal = Color(0xFF1D8FA0);
  static const Color primaryTealDark = Color(0xFF0E6E80);

  // Bright cyan used for the main CTA button ("Create an Account")
  static const Color accentCyan = Color(0xFF29C1E8);

  // Secondary button (outlined "Sign in")
  static const Color secondaryButtonBg = Colors.white;
  static const Color secondaryButtonBorder = Color(0xFFE0F4F8);

  // Backgrounds
  static const Color background = Colors.white;
  static const Color illustrationBgCircle = Color(0xFFDCEFF6);

  // Text
  static const Color textDark = Color(0xFF1D3A45);
  static const Color textSubtitle = Color(0xFF2E8B9A);
  static const Color textOnPrimaryButton = Colors.white;

  // Misc accents used in the illustration badges
  static const Color badgeRed = Color(0xFFE86A5E);
  static const Color badgeCircleBg = Colors.white;
}
