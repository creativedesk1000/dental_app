import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

/// Placeholder illustration for the splash screen (tooth + dentist +
/// medical badges), built from Flutter primitives so the screen renders
/// out of the box with no image assets required.
///
/// For a pixel-perfect match to your mockup, export the artwork from
/// Figma as a PNG/SVG and swap this widget's body for:
///   Image.asset('assets/images/splash_illustration.png')
/// (an `assets/images/` folder is already scaffolded for you).
class SplashIllustration extends StatelessWidget {
  final double size;

  const SplashIllustration({super.key, this.size = 240});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: size,
      height: size,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Soft background cloud/blob
          Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              color: AppColors.illustrationBgCircle,
              borderRadius: BorderRadius.circular(size * 0.4),
            ),
          ),
          // Tooth shape
          Positioned(
            bottom: size * 0.12,
            child: Icon(
              Icons.sentiment_satisfied_alt_rounded,
              size: size * 0.42,
              color: Colors.white,
              shadows: [
                Shadow(
                  color: Colors.grey.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
          ),
          Positioned(
            bottom: size * 0.12,
            child: Icon(
              Icons.circle,
              size: size * 0.46,
              color: Colors.white,
            ),
          ),
          Positioned(
            bottom: size * 0.14,
            child: Icon(
              Icons.medical_services_rounded,
              size: size * 0.24,
              color: AppColors.primaryTeal.withOpacity(0.85),
            ),
          ),
          // Dentist figure (simplified)
          Positioned(
            right: size * 0.08,
            bottom: size * 0.02,
            child: Icon(
              Icons.person,
              size: size * 0.42,
              color: AppColors.primaryTeal,
            ),
          ),
          // Top-left medical cross badge
          Positioned(
            top: size * 0.16,
            left: size * 0.06,
            child: _BadgeCircle(icon: Icons.add, color: AppColors.badgeRed),
          ),
          // Lower-left medical cross badge
          Positioned(
            bottom: size * 0.28,
            left: size * 0.0,
            child: _BadgeCircle(icon: Icons.add, color: AppColors.badgeRed),
          ),
        ],
      ),
    );
  }
}

class _BadgeCircle extends StatelessWidget {
  final IconData icon;
  final Color color;

  const _BadgeCircle({required this.icon, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: AppColors.badgeCircleBg,
        shape: BoxShape.circle,
        border: Border.all(color: color, width: 1.5),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Icon(icon, color: color, size: 18),
    );
  }
}
